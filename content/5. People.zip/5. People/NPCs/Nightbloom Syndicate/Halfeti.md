---
name: "Halfeti"
type: npc
location: "[[Sylvandar / Nightbloom Syndicate]]"
affiliations:
  - "[[Nightbloom Syndicate]]"
  - "[[Sylvandar Republic]]"
sources:
  - "sylvandar full final.docx"
occurrences: 1
tags:
  - npc
  - nightbloom-syndicate
---

# Halfeti

## Overview
- **Location / Context:** [[Sylvandar / Nightbloom Syndicate]]
- **Affiliation:** [[Nightbloom Syndicate]], [[Sylvandar Republic]]
- **Occurrences in source material:** 1

## Role & Notes
- Blonde high elf leader of [[The Nightbloom Syndicate]]
- appears hooded and keeps her face partly hidden.

## Source Documents
- [[Sylvandar]] full final.docx

## Paragraph References
- Manual add from [[Sylvandar]] Nightbloom section
